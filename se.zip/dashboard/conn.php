<?php
$connection=mysqli_connect('localhost', 'kvief6z2_se', 'kvief6z2_se', 'kvief6z2_se');
if(!$connection){
 echo "Database Connection Failed";
}
?>