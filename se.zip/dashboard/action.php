<?php
session_start();
include_once('conn.php');
$con=$GLOBALS['connection'];

if(isset($_POST['signinbtn'])){
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		$query = "SELECT * FROM user WHERE user='$user' AND pass='$pass'";
    	$query_run = mysqli_query($con, $query);
    
        if($query_run){
            $_SESSION['pass'] = $pass;
            $_SESSION['user']=$user;

            header('location: dashboard.php');
        }
        else {
            $_SESSION['status'] = "Oops! Something went wrong! Please recheck the credentials and try again!";
            header('location: login.php'); 
        }
}

if(isset($_POST['signupbtn'])){
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		$pin=$_POST['pin'];
 		$query = "INSERT INTO user (user, pass, pin) VALUES ('$user', '$pass', '$pin')";
        $query_run = mysqli_query($con, $query);
    
        if($query_run){
            $_SESSION['success'] = "User Profile Added";
            $_SESSION['user']=$user;
            $_SESSION['pin']=$pin;
            header('location: register.php');
        }
        else {
            $_SESSION['status'] = "Oops! Something went wrong! User Profile NOT Added";
            header('location: signup.php'); 
        }
}

if(isset($_POST['registerbtn'])){
		$user=$_SESSION['user'];
		$mob=$_POST['mob'];
		$expsalary=$_POST['expsalary'];
		$email=$_POST['email'];
		$name=$_POST['name'];
		$gender=$_POST['gender'];
		$dob=$_POST['dob'];
		$e1=$_POST['e1'];
		$ed1=$_POST['ed1'];
		$e2=$_POST['e2'];
		$ed2=$_POST['ed2'];
		$p1=$_POST['p1'];
		$pd1=$_POST['pd1'];
		$p2=$_POST['p2'];
		$pd2=$_POST['pd2'];
		$p3=$_POST['p3'];
		$pd3=$_POST['pd3'];
		$a1=$_POST['a1'];
		$a2=$_POST['a2'];
		$a3=$_POST['a3'];
		$a4=$_POST['a4'];
		$s1=$_POST['s1'];
		$s2=$_POST['s2'];
		$s3=$_POST['s3'];
		$s4=$_POST['s4'];
		$skills=$_POST['skills'];
		$job1=$_POST['job1'];
		$jobd1=$_POST['jobd1'];
		$job2=$_POST['job2'];
		$jobd2=$_POST['jobd2'];
		$job3=$_POST['job3'];
		$jobd3=$_POST['jobd3'];
		$job4=$_POST['job4'];
		$jobd4=$_POST['jobd4'];
		
 		$query = "UPDATE user SET mob='$mob', email='$email', name='$name', expsalary='$expsalary' WHERE user='$user' ";
    	$query_run = mysqli_query($con, $query);

    	$query2 = "UPDATE user SET job1='$job1', jobd1='$jobd1', job2='$job2', jobd2='$jobd2', job3='$job3', jobd3='$jobd3', job4='$job4', jobd4='$jobd4' WHERE user='$user' ";
    	$query_run2 = mysqli_query($con, $query2);

    	$query3 = "UPDATE user SET p1='$p1', pd1='$pd1', p2='$p2', pd2='$pd2', p3='$p3', pd3='$pd3' WHERE user='$user' ";
    	$query_run3 = mysqli_query($con, $query3);

    	$query4 = "UPDATE user SET e1='$e1', ed1='$ed1', e2='$e2', ed2='$ed2' WHERE user='$user' ";
    	$query_run4 = mysqli_query($con, $query4);

    	$query5 = "UPDATE user SET a1='$a1', a2='$a2', a3='$a3', a4='$a4' WHERE user='$user' ";
    	$query_run5 = mysqli_query($con, $query5);

    	$query6 = "UPDATE user SET s1='$s1', s2='$s2', s3='$s3', s4='$s4', skills='$skills' WHERE user='$user' ";
    	$query_run6 = mysqli_query($con, $query6);
    
        if($query_run && $query_run2 && $query_run3 && $query_run4 && $query_run5 && $query_run6){
            $_SESSION['updates'] = "User Profile Details Updated Successfully!";
            
            header('location: dashboard.php');
        }
        else {
            $_SESSION['status'] = "Oops! Something went wrong! User Profile NOT Added";
            header('location: register.php'); 
        }
}


if(isset($_POST['forgotbtn'])){
		$user=$_POST['user'];
		$pin=$_POST['pin'];
		$pass="";
 		$query = "SELECT * FROM user WHERE user='$user' AND pin='$pin'";
    	$query_run = mysqli_query($con, $query);
    	 if (mysqli_num_rows($query_run) > 0) {
    		while($row = mysqli_fetch_assoc($query_run)) {
    			$pass=$row['pass'];
    		}
    	}
        if($query_run){
            $_SESSION['pass'] = $pass;
            $_SESSION['user']=$user;
            $_SESSION['forgot']=$pass;
            header('location: forgot.php');
        }
        else {
            $_SESSION['status'] = "Oops! Something went wrong! Please recheck the credentials and try again!";
            header('location: login.php'); 
        }
}

?>